﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Biblioteca
{
    public class Biblioteca
    {
        //Será implementado uma HASH de Estudante
        //Será implementado uma HASH de Livros

        //Será implementado uma arvore AVL para os emprestimos que consistem em
        //na hora de ser "Criado ir na Hash de estudante passando o CODIGO por parametro buscando seus dados
        //em conjunto com o livro, sendo consultado na sua HASH pelo CODIGO tb... sendo localizado 
        //na hora de criar o emprestimo, criar uma REF para o livro e uma REF para o ALUNO, inseri-los no metodo de criação
        //da Arvore para serem pesquisados por exemplo, ALuno X, nele temos X livros... a partir dele podemos pesquisar no
        //nodo na arvore e gerar relatórios.... (extrair os dados para uma vetor) organizar etc...


    }
}
